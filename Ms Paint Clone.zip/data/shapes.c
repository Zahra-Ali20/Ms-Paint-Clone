#include "data_header.h"
void printfilledhexagon(int size, char symbol, int x, int y)
{
    gotoxy(x, y);
    int i, j;
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, " %c", symbol);
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, " %c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= size; i++)
    {

        for (int j = 1; j <= size + 1; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, " %c", symbol);
        }
        for (int j = 1; j <= size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, " %c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, " %c", symbol);
        }
        for (int j = i; j < size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, " %c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printhollowhexagon(int size, char symbol, int x, int y)
{
    gotoxy(x, y);
    int i, j;
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)

            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= size; i++)
    {

        for (int j = 1; j <= size; j++)
        {
            if (j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = 1; j <= size; j++)
        {
            if (j == size)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void hollowbutterfly(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i < size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
         {       printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j < size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
              {  printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {

        for (int j = i; j <= size; j++)
        {
            if (j == i || j == size)
            {    printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= size; j++)
        {
            if (j == i || j == size)
              {  printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void filledbutterfly(int size, int symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i < size; i++)
    {
        for (int j = 1; j <= i; j++)
        {

            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        for (int j = i; j < size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {

            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {

        for (int j = i; j <= size; j++)
        {

            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= size; j++)
        {

            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printHollowCircle(int radius, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = -radius; i <= radius; i++)
    {
        for (int j = -radius; j <= radius; j++)
        {
            if (fabs(sqrt(i * i + j * j) - radius) < 0.5)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  "); // Print a space for points outside the circle
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printFilledCircle(int radius, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = -radius; i <= radius; i++)
    {
        for (int j = -radius; j <= radius; j++)
        {
            if (sqrt(i * i + j * j) <= radius)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  "); // Print a space for points outside the circle
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printFilleddiamond(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i < size + 1; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        for (int j = 1; j <= i; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= size + 1; i++)
    {
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j < size + 1; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        for (int j = i; j <= size + 1; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printHollowdiamond(int size, char symbol, int x, int y)
{
    gotoxy(x, y);
    for (int i = 1; i < size + 1; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
             {   printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
               { printf(" ");
            fprintf(fptr, " ");}
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
              {  printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= size + 1; i++)
    {
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i)
          {      printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size)
       {         printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

// for half diamond:
void drawhalfhollowdiamond(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    int i, j;

    for (i = 1; i <= size; i++)
    {
        for (j = 1; j <= size - i; j++)
            printf(" ");
        fprintf(fptr, " ");
        for (j = 1; j <= 2 * i - 1; j++)
        {
            if (j == 1 || j == 2 * i - 1 || i == size)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
// for half diamond(hollow):
void drawFilledhalfdiamond(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    int i, j;

    for (i = 1; i <= size; i++)
    {
        for (j = 1; j <= size - i; j++)
            printf(" ");
        fprintf(fptr, " ");
        for (j = 1; j <= 2 * i - 1; j++)
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void horizontalline(int length, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= length; i++)
    {
        printf("-");
    }
    printf("\n");
    fprintf(fptr, "\n");
    y++;
    gotoxy(x, y);
}
void verticalline(int length, int x, int y)
{
    gotoxy(x, y);

    int i, j;
    for (int j = 0; j < length; j++)
    {
        printf("|\n");
        y++;
        gotoxy(x, y);
    }
    printf("\n");
    fprintf(fptr, "\n");
      y++;
    gotoxy(x, y);
}
void drawFilledOval(int width, int height, char symbol, int choice, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= width; j++)
            if (i == 1 && j != width && j != 1 || j <= width && i != 1 && i != height || j == 1 && i != 1 && i != height || i == height && j != 1 && j != width)

            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void drawhollowoval(int width, int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= width; j++)
            if (i == 1 && j != width && j != 1 || j == width && i != 1 && i != height || j == 1 && i != 1 && i != height || i == height && j != 1 && j != width)

            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void drawFilledparallelogram(int width, int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < width; i++)
    {
        for (int j = 0; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 0; j < height; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void drawhollowparallelogram(float width, float height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < width; i++)
    {
        for (int j = 0; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 0; j < height; j++)
        {
            if (i == 0 || i == width - 1 || j == 0 || j == height - 1)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printFilledPentagon(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)

        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        for (int j = 1; j <= i; j++)
        {

            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printHollowPentagon(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == size || j == 1 || j == size)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void drawHollowPyramid(int size, char symbol, int x, int y)
{
    gotoxy(x, y);
    int i, j;

    for (i = 1; i <= size; i++)
    {
        for (j = 1; j <= size - i; j++)
            printf(" ");
        fprintf(fptr, " ");
        for (j = 1; j <= 2 * i - 1; j++)
        {
            if (j == 1 || j == 2 * i - 1 || i == size)
               { printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void drawFilledPyramid(int size, char symbol, int x, int y)
{
    int i, j;
    gotoxy(x, y);

    for (i = 1; i <= size; i++)
    {
        for (j = 1; j <= size - i; j++)
            printf(" ");
        fprintf(fptr, " ");
        for (j = 1; j <= 2 * i - 1; j++)
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void drawFilledrectangle(int width, int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= width; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void drawhollowrectangle(float width, float height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < width; i++)
    {
        for (int j = 0; j < height; j++)
        {
            if (i == 0 || i == width - 1 || j == 0 || j == height - 1)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void hollow6sidedstar(int length, char symbol, int x, int y)
{
    gotoxy(x, y);

    int i, j;
    for (int i = 1; i <= length; i++)
    {
        for (int j = 1; j <= length; j++)
        {
            if (i == length)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = i; j < length; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j < length; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < length; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = 1; j <= length; j++)
        {
            if (i == length)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= length; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j <= length; j++)
        {
            if (j == i)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= length; j++)
        {
            printf("   ");
        }
        for (int j = 1; j <= length; j++)
        {
            printf("   ");
        }
        for (int j = i; j <= length; j++)
        {
            if (j == length)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= length; i++)
    {
        for (int j = i; j <= length; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= length; j++)
        {
            if (j == i)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        for (int j = i; j <= length; j++)
        {
            if (j == length)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j <= length; j++)
        {
            if (j == i)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        for (int j = i; j <= length; j++)
        {
            if (j == length)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void filled6sidedstar(int length, char symbol, int x, int y)
{
    gotoxy(x, y);
    for (int i = 1; i <= length; i++)
    {
        for (int j = 1; j <= length; j++)
        {
            if (i == length)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = i; j < length; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j < i; j++)

        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }

        for (int j = 1; j <= i; j++)

        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }

        for (int j = i; j < length; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < length; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j < i; j++)
        {

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }
        for (int j = 1; j <= i; j++)
        {

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }

        for (int j = 1; j <= length; j++)
        {
            if (i == length)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= length; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j <= length; j++)
        {

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }

        for (int j = 1; j <= length; j++)
        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }
        for (int j = 1; j <= length; j++)
        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }
        for (int j = 1; j <= length; j++)
        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }
        for (int j = i; j <= length; j++)

        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= length; i++)
    {
        for (int j = i; j <= length; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= length; j++)

        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }

        for (int j = i; j <= length; j++)
        {
            if (i == 1 || j == i)

            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j <= length; j++)

        {
            printf(" %c", symbol);
            fprintf(fptr, " %c", symbol);
        }

        for (int j = i; j <= length; j++)
        {
            if (j != 2 && j != length && j != length - 1)

            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void hollow4sidedstar(int length, char symbol, int x, int y)
{
    gotoxy(x, y);
    for (int i = 1; i < length; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
              {  printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j < length; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= length; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
               { printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= length; i++)
    {

        for (int j = i; j <= length; j++)
        {
            if (j == i || j == length)
              {  printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= length; j++)
        {
            if (j == i || j == length)
             {   printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
             {   printf(" ");
            fprintf(fptr, " ");}
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void filled4sidedstar(int length, int symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i < length; i++)
    {
        for (int j = 1; j <= i; j++)
        {

            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        for (int j = i; j < length; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= length; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {

            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= length; i++)
    {

        for (int j = i; j <= length; j++)
        {

            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= length; j++)
        {

            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void drawFilledTrapezium(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    int spaces;

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= size; j++)
        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }

        for (int j = 1; j < i; j++)
        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void drawHollowTrapezium(int size, char symbol, int x, int y)
{
    int spaces;
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j <= size; j++)
            if (i == size || j == 1 || i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }

        for (int j = 1; j < i; j++)
            if (j == size || i == size)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        for (int j = 1; j <= size; j++)
            if (j == i || i == size && j != size)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printFilledLeftTriangle(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printHollowLeftTriangle(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (i == 1 || j == 1 || i == j || j == height || i == height)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printFilledRightTriangle(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= height - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printHollowRightTriangle(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= height - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i || i == height)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printFilledInvertedRightTriangle(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = height; i >= 1; i--)
    {
        for (int j = 1; j <= height - i; j++)
        {

            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printHollowInvertedRightTriangle(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = height; i >= 1; i--)
    {
        for (int j = 1; j <= height - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i || i == 1 || i == height || j == height)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printFilledInvertedLeftTriangle(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = height; i >= 1; i--)
    {
        for (int j = 1; j <= i - 1; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }
        for (int j = height; j >= i; j--)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printHollowInvertedLeftTriangle(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = height; i >= 1; i--)
    {
        for (int j = 1; j <= i; j++)
        {
            if (i == 1 || i == height || j == 1 || j == height || i == j)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        for (int j = height; j >= i; j--)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printFilledKite(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    int mid = height / 2;

    // Print the filled kite shape
    for (int i = 0; i <= mid; i++)
    {
        for (int j = 0; j < mid - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 0; j < 2 * i + 1; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = mid - 1; i >= 0; i--)
    {
        for (int j = 0; j < mid - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 0; j < 2 * i + 1; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printHollowKite(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    int mid = height / 2;

    // Print the hollow kite shape
    for (int i = 0; i <= mid; i++)
    {
        for (int j = 0; j < mid - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 0; j < 2 * i + 1; j++)
        {
            if (j == 0 || j == 2 * i)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = mid - 1; i >= 0; i--)
    {
        for (int j = 0; j < mid - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 0; j < 2 * i + 1; j++)
        {
            if (j == 0 || j == 2 * i)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void FilledSquare(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void HollowSquare(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            if (i == 0 || i == size - 1 || j == 0 || j == size - 1)
            {
                {
                    printf("%c ", symbol);
                    fprintf(fptr, "%c ", symbol);
                }
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void drawupperarrow(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        for (int j = 1; j <= i; j++)
        {
            if (j == i || j == 1)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == size)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        for (int j = 1; j <= i; j++)
        {
            if (j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void drawlowerarrow(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == size)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        for (int j = 1; j <= i; j++)
        {
            if (j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void drawleftarrow(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1 || i == size)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j < i; j++)
        {
            if (i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i || j == size || i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void drawrightarrow(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= ((2 * size) - 1); j++)
        {
            if (j == (size + (i - 1)))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else if (i == size)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = size - 1; i >= 1; i--)
    {
        for (int j = 1; j <= ((2 * size) - 1); j++)
        {
            if (j == (size + (i - 1)))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printchatbox(int rows, int column, const char *message, int x, int y)
{
    gotoxy(x, y);

    // For message
    if (strlen(message) > (column - 2) || rows < 3)
    {
        printf("The message is too long or the rectangle is too small to display the message.\n");
        return;
    }
    for (int i = 1; i <= rows; i++)
    {
        for (int j = 1; j <= column; j++)
        {
            if (i == 1 || i == rows || j == 1 || j == column)
            {
                printf("*");
            }
            else if (i == rows / 2 + 1 && j == (column - strlen(message)) / 2 + 1)
            {
                printf("%s", message);
                j += strlen(message) - 1;
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void filledheart(int height, int width, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = height / 2; i <= height; i += 2)
    {
        for (int j = 1; j < height - i; j += 2)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= i; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        for (int j = 1; j <= height - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= i; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = height; i >= 1; i--)
    {
        for (int j = i; j < height; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= 2 * i - 1; j++)
        {
            printf("%c", symbol);
            fprintf(fptr,"%c",symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void hollowheart(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = height / 2; i <= height; i += 2)
    {
        for (int j = 1; j < height - i; j += 2)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
              {  printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= height - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
             {   printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    // Lower part of the hollow heart
    for (int i = height; i >= 1; i--)
    {
        for (int j = i; j < height; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= (i * 2) - 1; j++)
        {
            if (j == 1 || j == (i * 2) - 1)
              {  printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printLetterA(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    int width = (2 * height) - 1;
    int mid = height;

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= height; j++)
        {
            if (j == mid || j == (height - mid + 1) || i == height / 2 + 1)
           {     printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        mid--;
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterB(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf("%c", symbol);
        fprintf(fptr,"%c",symbol);
        for (int j = 0; j < height - 1; j++)
        {
            if ((i == 0 || i == height - 1 || i == height / 2) && j < height - 2)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else if (j == height - 2 && !(i == 0 || i == height - 1 || i == height / 2))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterC(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf("%c", symbol);
        fprintf(fptr,"%c",symbol);
        for (int j = 0; j < height - 1; j++)
        {
            if ((i == 0 || i == height - 1) && j < height - 2)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterD(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf("%c", symbol);
        fprintf(fptr,"%c",symbol);
        for (int j = 0; j < height; j++)
        {
            if ((i == 0 || i == height - 1) || (j == 0 && i < height - 1) || (j == height - 1 && i < height - 1))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterE(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf("%c", symbol);
        fprintf(fptr,"%c",symbol);
        for (int j = 0; j < height; j++)
        {
            if ((i == 0 || i == height - 1) || (i == height / 2 && j <= height / 2))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterF(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf(" %c", symbol);
        fprintf(fptr, " %c", symbol);
        for (int j = 0; j < height; j++)
        {
            if ((i == 0) || (i == height / 2 && j <= height / 2))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printLetterG(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    int i, j;
    for (i = 0; i < height; i++)
    {
        for (j = 0; j < height; j++)
        {
            if ((i == 0 && (j >= 1 && j < height)) ||
                (i == height - 1 && (j >= 1 && j < height)) ||
                (j == 0 && (i >= 1 && i < height - 1)) ||
                ((i == height / 2) && (j >= height / 2)) ||
                ((j == height - 1) && (i >= height / 2)))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterH(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    int i, j;
    for (i = 1; i <= height; i++)
    {

        for (j = 1; j <= height; j++)
        {
            if (j == 1 || j == height || i == height / 2 + 1)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterI(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    int i, j;
    for (i = 1; i <= height; i++)
    {

        for (j = 1; j <= height; j++)
        {
            if (i == 1 || i == height || j == height / 2 + 1)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printLetterJ(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < height; j++)
        {
            if (i == 0 || (j == height / 2 && i < height - 1) || (i == height - 1 && j <= height / 2))
              {  printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterK(int height, char symbol, int x, int y)
{
    gotoxy(x, y);
    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= height; j++)
        {
            if (j == 3)
               { printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= height; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == 1)
            {    printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= height; j++)
        {
            if (j == 3)
    {            printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j <= height; j++)
        {
            if (j == i)
        {        printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printLetterL(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    int i, j;
    for (i = 1; i <= height; i++)
    {

        for (j = 1; j <= height; j++)
        {
            if (j == 1 || i == height)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printLetterM(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= height; j++)
        {
            if (j == 1 || i == j || i + j == height + 1 || j == height)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printLetterN(int height, char symbol, int x, int y)
{
    gotoxy(x, y);
    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= height; j++)
        {
            if (j == 1 || j == height + 1 || i == j || j == height)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
int printLetterO(int height, char symbol, int x, int y)
{
    gotoxy(x, y);
    if (height < height)
    {
        return 1;
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < height; j++)
        {
            if ((i == 0 || i == height - 1) || (j == 0 || j == height - 1))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
int printLetterP(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    if (height < height)
    {
        return 1;
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < height; j++)
        {
            if ((j == 0) || (i == 0 && j < height - 1) || (i == height / 2 && j < height - 1) || (j == height - 1 && i <= height / 2))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
int printLetterQ(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    if (height < height)
    {

        return 1;
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < height; j++)
        {
            if ((j == 0 && i != 0 && i != height - 1) ||
                (j == height - 1 && i != 0 && i != height - 1) ||
                (i == 0 && j > 0 && j < height - 1) ||
                (i == height - 1 && j > height / 3) ||
                (j == height / 3 && i >= height / 3))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
int printLetterR(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    if (height < height)
    {
        return 1;
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < height; j++)
        {
            if (j == 0 || (i == 0 && j < height - 1) || (i == height / 2 && j < height - 1) ||
                (j == height - 1 && i <= height / 2) || (i == j && i > height / 2))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printLetterS(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < 2 * height - 1; j++)
        {
            if (i + j == height - 1 || j - i == height - 1)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterT(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf(" %c", symbol);
        fprintf(fptr, " %c", symbol);
        for (int j = 0; j < height - 1; j++)
        {
            if ((i == 0 || i == height - 1 || i == height / 2) && j < height - 2)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else if (j == height - 2 && !(i == 0 || i == height - 1 || i == height / 2))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterU(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf(" %c", symbol);
        fprintf(fptr, " %c", symbol);
        for (int j = 0; j < height - 1; j++)
        {
            if ((i == 0 || i == height - 1) && j < height - 2)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterV(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf(" %c", symbol);
        fprintf(fptr, " %c", symbol);
        for (int j = 0; j < height; j++)
        {
            if ((i == 0 || i == height - 1) || (j == 0 && i < height - 1) || (j == height - 1 && i < height - 1))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterW(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf("%c", symbol);
        fprintf(fptr,"%c",symbol);
        for (int j = 0; j < height; j++)
        {
            if ((i == 0 || i == height - 1) || (i == height / 2 && j <= height / 2))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterX(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 0; i < height; i++)
    {
        printf("%c", symbol);
        fprintf(fptr,"%c",symbol);
        for (int j = 0; j < height; j++)
        {
            if ((i == 0) || (i == height / 2 && j <= height / 2))
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void printLetterY(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j < i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = i; j < height; j++)
        {
            if (j == i)
            {    printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = i; j <= height; j++)
        {
            if (j == height)
            {    printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
            fprintf(fptr, " ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= height; j++)
        {
            if (j == height / 2 + 1)
            {
                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void printLetterZ(int height, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= height; j++)
            if (i == 1 || i == height || i + j == height + 1)
            {    printf("%c", symbol);
                fprintf(fptr,"%c",symbol);}
            else
                printf(" ");
        fprintf(fptr, " ");
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void num1(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

   for (int i = 1; i <= size; i++) {
        for (int j = 1; j <= size / 2 + 1; j++) {
            if (j == size / 2 + 1 || (i == 1 && j!= 1||i==2&&j==1||i==size)) {
                printf(" %c",symbol);
                fprintf(fptr, " %c", symbol);
            } else {
                printf("  ");
                 fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
            }
        }

void num2(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (i == size || j == size || i == 1)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (j == 1 || i == size)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void num3(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (i == size || j == size || i == 1)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (j == size || i == size)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void num4(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (i == size || j == 1 || j == size)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (j == size)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void num5(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (i == size || j == 1 || i == 1)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (j == size || i == size)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void num6(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (j == 1 || i == 1)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (j == size || i == size || j == 1 || i == 1)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}

void num7(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (i == 1 || i + j == size + 1)
            {

                printf("%c", symbol);
                fprintf(fptr,"%c",symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void num8(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (i == size || j == 1 || i == 1 || j == size)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (j == size || i == size || j == 1)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}
void num9(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (i == size || j == 1 || i == 1 || j == size)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            if (j == size || i == size)
            {

                printf(" %c", symbol);
                fprintf(fptr, " %c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x, y);
    }
}