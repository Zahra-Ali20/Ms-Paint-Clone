void bluecolour();
void redcolour();
void greencolour();
void yellowcolour();
void whitecolour();
void getConsoleSize(int *width);
int gotoxy(int x, int y);