#define DATA_HEADER_FILE


#include"shapes.h"
#include"utility.h"

#include<stdio.h>
#include <math.h>
#include <string.h>
#include <windows.h>
#include<unistd.h>
#include<conio.h>

extern FILE *fptr;
