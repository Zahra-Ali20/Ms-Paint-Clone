#include "brain_header.h"
void hexagon(int choice, int size, char symbol, int x, int y)
{
    if (choice == 1)
    {
        printfilledhexagon(size, symbol, x, y);
    }
    else if (choice == 2)
    {

        printhollowhexagon(size, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void butterfly(int choice, int size, char symbol, int x, int y)
{
    if (choice == 1)
    {
        hollowbutterfly(size, symbol, x, y);
    }
    else if (choice == 2)
    {

        filledbutterfly(size, symbol, x, y);
    }
}
void circle(int choice, int radius, char symbol, int x, int y)
{
    if (choice == 1)
    {
        printHollowCircle(radius, symbol, x, y);
    }
    else if (choice == 2)
    {

        printFilledCircle(radius, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void diamond(int choice, int size, char symbol, int x, int y)
{
    if (choice == 1)
    {
        printFilleddiamond(size, symbol, x, y);
    }
    else if (choice == 2)
    {

        printHollowdiamond(size, symbol, x, y);
    }
    else if (choice == 3)
    {
        drawhalfhollowdiamond(size, symbol, x, y);
    }
    else if (choice == 4)
    {
        drawFilledhalfdiamond(size, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void line(int choice, int length, int x, int y)
{
    if (choice == 1)
    {
        horizontalline(length, x, y);
    }
    else if (choice == 2)
    {

        verticalline(length, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void Oval(int width, int height, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        drawFilledOval(width, height, symbol, choice, x, y);
    }
    else if (choice == 2)
    {

        drawhollowoval(width, height, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void parallelogram(int width, int height, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        drawFilledparallelogram(width, height, symbol, x, y);
    }
    else if (choice == 2)
    {

        drawhollowparallelogram(width, height, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void Pentagon(int size, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        printFilledPentagon(size, symbol, x, y);
    }
    else if (choice == 2)
    {

        printHollowPentagon(size, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void Pyramid(int size, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        drawHollowPyramid(size, symbol, x, y);
    }
    else if (choice == 2)
    {

        drawFilledPyramid(size, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void rectangle(int width, int height, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        drawFilledrectangle(width, height, symbol, x, y);
    }
    else if (choice == 2)
    {

        drawhollowrectangle(width, height, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void star(int length, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        hollow6sidedstar(length, symbol, x, y);
    }
    else if (choice == 2)
    {

        filled6sidedstar(length, symbol, x, y);
    }
    else if (choice == 3)
    {
        hollow4sidedstar(length, symbol, x, y);
    }
    else if (choice == 4)
    {
        filled4sidedstar(length, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void Trapezium(int size, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        drawFilledTrapezium(size, symbol, x, y);
    }
    else if (choice == 2)
    {

        drawHollowTrapezium(size, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void Triangle(int height, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        printFilledLeftTriangle(height, symbol, x, y);
    }
    else if (choice == 2)
    {

        printHollowLeftTriangle(height, symbol, x, y);
    }
    else if (choice == 3)
    {
        printFilledRightTriangle(height, symbol, x, y);
    }
    else if (choice == 4)
    {
        printHollowRightTriangle(height, symbol, x, y);
    }
    else if (choice == 5)
    {
        printFilledInvertedRightTriangle(height, symbol, x, y);
    }
    else if (choice == 6)
    {
        printHollowInvertedRightTriangle(height, symbol, x, y);
    }
    else if (choice == 7)
    {
        printFilledInvertedLeftTriangle(height, symbol, x, y);
    }
    else if (choice == 8)
    {
        printHollowInvertedLeftTriangle(height, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void Kite(int height, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        printFilledKite(height, symbol, x, y);
    }
    else if (choice == 2)
    {

        printHollowKite(height, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void Square(int size, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        FilledSquare(size, symbol, x, y);
    }
    else if (choice == 2)
    {

        HollowSquare(size, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void arrows(int size, char symbol, int choice, int x, int y)
{
    if (choice == 1)
    {
        drawupperarrow(size, symbol, x, y);
        ;
    }
    else if (choice == 2)
    {

        drawlowerarrow(size, symbol, x, y);
    }
    else if (choice == 3)
    {
        drawleftarrow(size, symbol, x, y);
    }
    else if (choice == 4)
    {
        drawrightarrow(size, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void chatbox(int rows, int column, char message[], int choice, int x, int y)
{
    if (choice == 1)
    {
        printchatbox(rows, column, message, x, y);

        ;
    }
    else
    {
        printf("invalid choice\n");
    }
}

void heart(int height, int width, char symbol, int choice, int x, int y)
{
   
    if (choice == 1)
    {
        filledheart(height, width, symbol, x, y);
    }
    else if (choice == 2)
    {

        hollowheart(height, symbol, x, y);
    }
    else
    {
        printf("invalid choice\n");
    }
}
void colour(int choice)
{
    if (choice == 1)
    {
        bluecolour();
        
    }
    else if (choice == 2)
    {
        redcolour();
        
    }
    else if (choice == 3)
    {
        greencolour();
        
    }
    else if (choice == 4)
    {
        yellowcolour();
        
    }
    else if (choice == 5)
    {
        whitecolour();
        
    }
    else
    {
        printf("invalid choice\n");
    }
}
void alphabets(char letter, int height, char symbol, char start, char end, int x, int y)
{
    for (int letter = start; letter <= end; letter++)
    {
        y = y + height;
        if (letter == 'a' || letter == 'A')
        {
            printLetterA(height, symbol, x, y);
        }
        else if (letter == 'b' || letter == 'B')
        {
            printLetterB(height, symbol, x, y);
        }
        else if (letter == 'c' || letter == 'C')
        {
            printLetterC(height, symbol, x, y);
        }
        else if (letter == 'd' || letter == 'D')
        {
            printLetterD(height, symbol, x, y);
        }
        else if (letter == 'e' || letter == 'E')
        {
            printLetterE(height, symbol, x, y);
        }
        else if (letter == 'f' || letter == 'F')
        {
            printLetterF(height, symbol, x, y);
        }
        else if (letter == 'g' || letter == 'G')
        {
            printLetterG(height, symbol, x, y);
        }
        else if (letter == 'h' || letter == 'H')
        {
            printLetterH(height, symbol, x, y);
        }
        else if (letter == 'i' || letter == 'I')
        {
            printLetterI(height, symbol, x, y);
        }
        else if (letter == 'j' || letter == 'J')
        {
            printLetterJ(height, symbol, x, y);
        }
        else if (letter == 'k' || letter == 'K')
        {
            printLetterK(height, symbol, x, y);
        }
        else if (letter == 'l' || letter == 'L')
        {
            printLetterL(height, symbol, x, y);
        }
        else if (letter == 'm' || letter == 'M')
        {
            printLetterM(height, symbol, x, y);
        }
        else if (letter == 'n' || letter == 'N')
        {
            printLetterN(height, symbol, x, y);
        }
        else if (letter == 'o' || letter == 'O')
        {
            printLetterO(height, symbol, x, y);
        }
        else if (letter == 'p' || letter == 'P')
        {
            printLetterP(height, symbol, x, y);
        }
        else if (letter == 'q' || letter == 'Q')
        {
            printLetterQ(height, symbol, x, y);
        }
        else if (letter == 'r' || letter == 'R')
        {
            printLetterR(height, symbol, x, y);
        }
        else if (letter == 's' || letter == 'S')
        {
            printLetterS(height, symbol, x, y);
        }
        else if (letter == 't' || letter == 'T')
        {
            printLetterT(height, symbol, x, y);
        }
        else if (letter == 'u' || letter == 'U')
        {
            printLetterU(height, symbol, x, y);
        }
        else if (letter == 'v' || letter == 'V')
        {
            printLetterV(height, symbol, x, y);
        }
        else if (letter == 'w' || letter == 'W')
        {
            printLetterW(height, symbol, x, y);
        }
        else if (letter == x || letter == 'X')
        {
            printLetterX(height, symbol, x, y);
        }
        else if (letter == 'y' || letter == 'Y')
        {
            printLetterY(height, symbol, x, y);
        }
        else if (letter == 'z' || letter == 'Z')
        {
            printLetterZ(height, symbol, x, y);
        }
        else
        {
            printf("Invalid letter selection.\n");
        }
    }
}
void num_(int size, char symbol, char start, char end, int x, int y)
{
    for (char number = start; number <= end; number++)
    {
        y = y + size*3;
        if (number == '1')
        {
            num1(size, symbol, x, y);
        }
        else if (number == '2')
        {
            num2(size, symbol, x, y);
        }
        else if (number == '3')
        {
            num3(size, symbol, x, y);
        }
        else if (number == '4')
        {
            num4(size, symbol, x, y);
        }
        else if (number == '5')
        {
            num5(size, symbol, x, y);
        }
        else if (number == '6')
        {
            num6(size, symbol, x, y);
        }
        else if (number == '7')
        {
            num7(size, symbol, x, y);
        }
        else if (number == '8')
        {
            num8(size, symbol, x, y);
        }
        else if (number == '9')
        {
            num9(size, symbol, x, y);
        }
       
    }
}