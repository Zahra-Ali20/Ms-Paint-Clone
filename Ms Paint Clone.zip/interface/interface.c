#include "interface_header.h"
#include "string.h"

// Define a struct for variables
struct object
{
    int size, type, rows, columns, coloumn, width, height, radius, length, choice, number;
    char symbol,letter, start, end;
};

void introduction()
{
    int width;
    getConsoleSize(&width);
    printf("Console width: %d\n", width);
    int asteriksperrow = width;
    for (int j = 0; j < asteriksperrow; j++)
    {
        printf("*");
    }
    printf("\n                                                                WELCOME TO MS_PAINT                                                                                                                  \n");
    for (int j = 0; j < asteriksperrow; j++)
    {
        printf("*");
    }
}
void MS_paint()
{
    int ms;
    introduction();
}
void intro()
{
    int width;
    // call the funct to get the console size
    getConsoleSize(&width);

    // use width and height varibales
    printf("Console Width: %d\n", width);
    int asteriksperrow = width;
    for (int j = 0; j < asteriksperrow; j++)
    {
        printf("*");
    }
    printf("\nOption_menu\n");
    for (int j = 0; j < asteriksperrow; j++)
    {
        printf("*");
    }
}
void option_menu()
{
    whitecolour();
    char opt;
    introduction();
    printf("Press 1 to Create Shapes \n ");
    printf("Press 2 to Draw Freehand \n ");
    printf("Press 3 to Save File \n ");
    printf("Press 4 to  view File \n ");
    printf("Press 5 to Edit File \n ");

    printf("q. Exit\n ");
    printf("Enter your Choice:");
    scanf(" %c", &opt);
    system("cls");

    switch (opt)
    {
    case '1':
        draw_shapes();
        break;
    case '2':
        freehand();

        break;
    case '3':
        save_file();
        break;
    case '4':
        view_file();
        break;
    case '5':
        edit_file();
        break;
    case '8':
    option_menu();
        
        break;
    default:
        printf("Invalid option selection.\n");
        break;
    }

    return;
}

void draw_shapes()
{
    char ch;
    whitecolour();

    printf("Press a to draw HEXAGON \n");
    printf("Press b to draw BUTTERFLY \n");
    printf("Press c to draw CIRCLE \n");
    printf("Press d to draw DIAMOND \n");
    printf("Press e to draw LINE\n");
    printf("Press f to draw OVAL \n");
    printf("Press g to draw PARALLELOGRAM \n");
    printf("Press h to draw PENTAGON \n");
    printf("Press i to draw PYRAMID \n");
    printf("Press j to draw RECTANGLE \n");
    printf("Press k to draw STAR \n");
    printf("Press l to draw TRAPEIZIUM \n");
    printf("Press m to draw TRIANGLE \n");
    printf("Press n to draw KITE \n");
    printf("Press o to draw SQUARE \n");
    printf("Press p to draw ARROWS \n");
    printf("Press q to draw CHATBOX \n");
    printf("Press r to draw HEART \n");
     printf("Press s to draw ALPHABETS \n");
      printf("Press t to draw Numbers \n");

    printf("Press backspace to go back to menu\n");
    printf("Press S to save file\n");
    printf("Press E to edit file \n");
    printf("Press enter to go to next option \n");

    while (1)
    {
        printf("\n");
        ch = getch();
        if (ch == 'a')
        {
            print_hexagon();
        }
        else if (ch == 'b')
        {
            print_butterfly();
        }
        else if (ch == 'c')
        {
            print_circle();
        }
        else if (ch == 'd')
        {
            print_diamond();
        }
        else if (ch == 'e')
        {
            line_();
        }
        else if (ch == 'f')
        {
            print_Oval();
        }
        else if (ch == 'g')
        {
            parallelogram_();
        }
        else if (ch == 'h')
        {
            print_Pentagon();
        }
        else if (ch == 'i')
        {
            draw_Pyramid();
        }
        else if (ch == 'j')
        {
            rectangle_();
        }
        else if (ch == 'k')
        {
            star_();
        }
        else if (ch == 'l')
        {
            Trapezium_();
        }
        else if (ch == 'm')
        {
            draw_Triangle();
        }
        else if (ch == 'n')
        {
            Kite_();
        }
        else if (ch == 'o')
        {
            Square_();
        }
        else if (ch == 'p')
        {
            draw_arrows();
        }
        else if (ch == 'q')
        {
            print_chatbox();
        }
        else if (ch == 'r')
        {
            draw_heart();
        }
        else if (ch == 's')
        {
            alphabets_();
        }
         else if (ch == 't')
        {
            print_numbers();
        }
        else if (ch == 8)
        {
            option_menu();
        }
        else if(ch=='w')
        {
            save_file();
        }
    }
    system("cls");
}

void print_hexagon()
{
    struct object hexa;
    printf("Enter the size of the print_hexagon: ");
    scanf("%d", &hexa.size);

    printf("Enter the symbol for the print_hexagon: ");
    scanf(" %c", &hexa.symbol);

    printf("Enter a choice: \n");

    printf("Press 1 for filled hexagon\n");
    printf("Press 2 for hollow hexagon\n");
    scanf("%d", &hexa.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    hexagon(hexa.choice, hexa.size, hexa.symbol, x, y);
}
void print_butterfly()
{

    struct object butterf;

    printf("Enter the size of the print_butterfly: ");
    scanf("%d", &butterf.size);

    printf("Enter the symbol for the print_butterfly: ");
    scanf(" %c", &butterf.symbol);
    printf("Enter a choice: ");

    printf("Choose one option:\n");
    printf("Press 1 for hollow butterfly\n");
    printf("Press 2 for filled butterfly\n");
    scanf("%d", &butterf.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    char symbol;
    int choice, size, color;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    butterfly(butterf.choice, butterf.size, butterf.symbol, x, y);
}
void print_circle()
{
    struct object cir;

    printf("Enter the radius of the print_circle: ");
    scanf("%d", &cir.radius);

    printf("Enter the symbol for the print_circle: ");
    scanf(" %c", &cir.symbol);
    printf("Enter a choice:\n ");

    printf("Press 1 for hollow circle \n");
    printf("Press 2 for filled circle\n");
    scanf("%d", &cir.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    circle(cir.choice, cir.radius, cir.symbol, x, y);
}
void print_diamond()
{
    struct object dia;
    printf("Enter the size of the print_diamond: ");
    scanf("%d", &dia.size);
    printf("Enter the symbol for the print_diamond: ");
    scanf(" %c", &dia.symbol);

    printf("Enter a choice: \n");
    printf("Press 1 for filled diamond \n");
    printf("Press 2 for hollow diamond\n");
    printf("Press 3 for hollow half diamond \n");
    printf("Press 4 for filled half diamond\n");
    scanf("%d", &dia.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    diamond(dia.choice, dia.size, dia.symbol, x, y);
}

void line_()
{
    struct object line_;

    printf("Enter the length of the line: ");
    scanf("%d", &line_.length);

    printf("Enter a choice:\n ");
    printf("Press 1 for horizontal line \n ");
    printf("Press 2 for Vertical line \n ");

    scanf("%d", &line_.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;

    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    line(line_.choice, line_.length, x, y);
}
void print_Oval()
{
    struct object Ova;

    printf("Enter the height of the print_object: ");
    scanf("%d", &Ova.height);
    printf("Enter the width: ");
    scanf("%d", &Ova.width);
    printf("Enter the symbol for the print_Oval: ");
    scanf(" %c", &Ova.symbol);
    printf("Enter a choice: ");
    printf("Press 1 for filled oval \n");
    printf("Press 2 for hollow oval\n");
    scanf("%d", &Ova.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    Oval(Ova.width, Ova.height, Ova.symbol, Ova.choice, x, y);
}
void parallelogram_()
{
    struct object parallelogram_;

    printf("Enter the height of the paralellogram: ");
    scanf("%d", &parallelogram_.height);
    printf("Enter the width: ");
    scanf("%d", &parallelogram_.width);
    printf("Enter the symbol for the paralellogram: ");
    scanf(" %c", &parallelogram_.symbol);
    printf("Enter a choice: ");
    printf("Enter 1 for filled \n");
    printf("Enter 2 for hollow \n");
    scanf("%d", &parallelogram_.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    parallelogram(parallelogram_.width, parallelogram_.height, parallelogram_.symbol, parallelogram_.choice, x, y);
}

void print_Pentagon()
{
    struct object print_Pentagon;
    printf("Enter the size of the print_pentagon: ");
    scanf("%d", &print_Pentagon.size);

    printf("Enter the symbol for the print_Pentagon: ");
    scanf(" %c", &print_Pentagon.symbol);
    printf("Enter a choice: ");

    printf("Choose one option:\n");
    printf("Press 1 for filled pentagon\n");
    printf("Press 2 for hollow pentagon\n");
    scanf("%d", &print_Pentagon.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    Pentagon(print_Pentagon.size, print_Pentagon.symbol, print_Pentagon.choice, x, y);
}
void draw_Pyramid()
{
    struct object draw_Pyramid;

    printf("Enter the size of the draw_pyramid: ");
    scanf("%d", &draw_Pyramid.size);

    printf("Enter the symbol for the print_Pentagon: ");
    scanf(" %c", &draw_Pyramid.symbol);
    printf("Enter a choice: ");

    printf("Choose one option:\n");
    printf("Press 1 for hollow pyramid\n");
    printf("Press 2 for filled pyramid\n");
    scanf("%d", &draw_Pyramid.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    Pyramid(draw_Pyramid.size, draw_Pyramid.symbol, draw_Pyramid.choice, x, y);
}
void rectangle_()
{
    struct object rectangle_;

    printf("Enter the width: ");
    scanf("%d", &rectangle_.width);

    printf("Enter the height of the rectangle: ");
    scanf("%d", &rectangle_.height);
    printf("Enter the symbol for the rectangle: ");
    scanf(" %c", &rectangle_.symbol);
    printf("Enter a choice: ");
    printf("Press 1 for filled rectangle \n");
    printf("Press 2 for hollow rectangle\n");

    scanf("%d", &rectangle_.choice);

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    rectangle(rectangle_.width, rectangle_.height, rectangle_.symbol, rectangle_.choice, x, y);
}

void star_()
{
    struct object star_;
    
    printf("Enter the size of the star: ");
    scanf("%d", &star_.size);

    printf("Enter the symbol for the star: ");
    scanf(" %c", &star_.symbol);
    printf("Enter a choice: ");
    printf("enter 1 for hollow6sided star \n");
     printf("enter 2 for filled6sided star \n");
      printf("enter 3 for hollow4sided star \n");
       printf("enter 4 for filled4sided star \n");
    scanf("%d", &star_.choice);
    
    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    star(star_.size, star_.symbol, star_.choice, x, y);
}
void Trapezium_()
{
    struct object trapezium_;
   
    printf("Enter the size of the trapezium: ");
    scanf("%d", &trapezium_.size);

    printf("Enter the symbol for the trapezium: ");
    scanf(" %c", &trapezium_.symbol);
    printf("Enter a choice: ");
    printf("Press 1 for filled");
     printf("Press 2 for hollow");

    scanf("%d", &trapezium_.choice);

    
    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    Trapezium(trapezium_.size, trapezium_.symbol, trapezium_.choice, x, y);
}
void draw_Triangle()
{
    struct object draw_Triangle;
    
    printf("Enter the size of the draw_Triangle: ");
    scanf("%d", &draw_Triangle.size);

    printf("Enter the symbol for the draw_Triangle: ");
    scanf(" %c", &draw_Triangle.symbol);

    printf("Choose one option:\n");
    printf("Press 1 for filled left triangle \n");
    printf("Press 2 for hollow left triangle\n");
    printf("Press 3 for filled right triangle \n");
    printf("Press 4 for hollow right triangle\n");
    printf("Press 5 for filled inverted right triangle \n");
    printf("Press 6 for hollow inverted right triangle\n");
    printf("Press 7 for filled inverted left triangle \n");
    printf("Press 8 for hollow inverted left triangle\n");
    printf("Enter a choice: ");
    scanf("%d", &draw_Triangle.choice);
    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    Triangle(draw_Triangle.size, draw_Triangle.symbol, draw_Triangle.choice, x, y);
}
void Kite_()
{
    struct object Kite_;
 
    printf("Enter the size of the Kite_: ");
    scanf("%d", &Kite_.size);

    printf("Enter the symbol for the Kite_: ");
    scanf(" %c", &Kite_.symbol);
   
     printf("Choose one option:\n");
     printf("Press 1 for filled kite \n");
    printf("Press 2 for hollow kite\n");
       scanf("%d", &Kite_.choice);
    

    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    Kite(Kite_.size, Kite_.symbol, Kite_.choice, x, y);
}
void Square_()
{
    struct object Square_;
    
    printf("Enter the size of the Square_: ");
    scanf("%d", &Square_.size);

    printf("Enter the symbol for the Square_: ");
    scanf(" %c", &Square_.symbol);
   

     printf("Choose one option:\n");
     printf("Press 1 for filled square\n");
     printf("Press 2 for hollow square\n");
     scanf("%d", &Square_.choice);
    
    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    char symbol;
    int choice, color, size;

    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    Square(Square_.size, Square_.symbol, Square_.choice, x, y);
}
void draw_arrows()
{
    struct object draw_arrows;
   
    printf("Enter the size of the  draw_arrows: ");
    scanf("%d", &draw_arrows.size);

    printf("Enter the symbol for the  draw_arrows: ");
    scanf(" %c", &draw_arrows.symbol);
    printf("Choose one option:\n");
    printf("Press 1 for upper arrow \n");
    printf("Press 2 for lower arrow\n");
    printf("Press 3 for left arrow \n");
    printf("Press 4 for right arrow\n");
    
    scanf("%d", &draw_arrows.choice);

    // scanf("%d", &choice);
    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    int choice;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    colour(color);
    arrows(draw_arrows.size, draw_arrows.symbol, draw_arrows.choice, x, y);
}
void print_chatbox()
{
    struct object print_chatbox;

    printf("Enter the number of rows: ");
    scanf("%d", &print_chatbox.rows);

    printf("Enter the number of columns: ");
    scanf("%d", &print_chatbox.columns);
    char message[100];
    printf("Enter the message to display inside the rectangle: ");
    scanf(" %[^\n]s", message);
    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);
    char messgae[100];
    int color;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    chatbox(print_chatbox.rows, print_chatbox.columns, message, print_chatbox.choice, x, y);
}
void draw_heart()
{
    struct object draw_heart;

    printf("Enter the height of the draw_heart: ");
    scanf("%d", &draw_heart.height);
   
    printf("Enter the width: ");
    scanf("%d", &draw_heart.width);
    printf("Enter the symbol for the draw_heart: ");
    scanf(" %c", &draw_heart.symbol);
    printf("Enter a choice: "); 
    printf("Press 1 for filled heart");
     printf("Press 2 for hollow heart");
    scanf("%d", &draw_heart.choice);
    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
    printf("%d", color);
    colour(color);

    heart(draw_heart.height, draw_heart.width, draw_heart.symbol, draw_heart.choice, x, y);
}

void alphabets_()
{
    struct object alphabet;
    printf("Enter the symbol for the alphabets: ");
    scanf(" %c", &alphabet.symbol);

    printf("Enter the height of the alphabets: ");
    scanf("%d", &alphabet.height);

    char start, end;
    printf("Enter the starting alphabet:\n");
    scanf(" %c",&alphabet.start);
    printf("Enter the end  alphabet:\n");
    scanf(" %c",&alphabet.end);
    
    int x, y;
    printf("Enter the Value of x:");
    scanf("%d", &x);
    printf("Enter the Value of y:");
    scanf("%d", &y);

    int color;
   char  letter;

    // printf("Enter a choice: ");
    //scanf("%d", &alphabet.choice);
     
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf("%d", &color);
     colour(color);

   
    
    alphabets(alphabet.letter, alphabet.height, alphabet.symbol, alphabet.start, alphabet.end, x, y);
}
void print_numbers()
{
    struct object printnumbers;
   
    printf("Enter the size of the numbers: ");
    scanf("%d", &printnumbers.size);
    printf("Enter the symbol for the numbers: ");
    scanf(" %c", &printnumbers.symbol);
    printf("Enter the starting number:\n");
    scanf(" %c", &printnumbers.start);
    printf("Enter the ending number:\n");
    scanf(" %c", &printnumbers.end);
    int x, y;
    printf("Enter the Value of x:");
    scanf(" %d", &x);
    printf("Enter the Value of y:");
    scanf(" %d", &y);
    int choice,color;
    printf("Enter colour: 1 for blue, 2 for red, 3 for green,4 for yellow 5 for white");
    scanf(" %d", &color);
     colour(color);
    num_( printnumbers.size,  printnumbers.symbol,  printnumbers.start,  printnumbers.end, x, y);
}
void free_hand()

{
    int x,y;
    char ch,symbol;
    gotoxy(x, y);

    while (1)
    {
        if (kbhit())
        {
            ch = getch();

            
            if (ch == 75) 
                x--;
            else if (ch == 77) 
                x++;
            else if (ch == 80) 
                y++;
            else if (ch == 72) 
                y--;

            
            gotoxy(x, y);
            printf(" ");
        }

        else
        {
            ch = getch();
            if (ch == 'r')
            {
                redcolour();
                gotoxy(x, y);
                printf("*");
            }
            else if (ch == 'y')
            {
                yellowcolour();
                gotoxy(x, y);
                printf("*");
            }
            else if (ch == 'g')
            {
                greencolour();
                gotoxy(x, y);
                printf("*");
            }
            else if (ch == 'b')
            {
                bluecolour();
                gotoxy(x, y);
                printf("*");
            }
            else if (ch == 32) 
            {
                whitecolour();
                gotoxy(x, y);
                printf("*");
            }
        }
        if (ch == 27) 
        {
            option_menu();
        }
    }
}

void freehand()
{
    int x;
    int y;
    printf("Enter the value of 'x': ");
    scanf(" %d", &x);
    printf("Enter the value of 'y': ");
    scanf(" %d", &y);
    printf("ENTER ESC FOR GOING BACK TO OPTION MENU");
    char ch;
    free_hand();
}

void save_file()
{
    char ch;
    fclose(fptr);
    FILE *fptr2;
    char file_name[100];
    printf("Enter file name: ");
    gets(file_name);
    gets(file_name);
    strcat(file_name, ".txt");
    fptr = fopen("hidden.txt", "r");
    fptr2 = fopen(file_name, "w"); // Use "a" mode for appending/creating

    if (fptr2 == NULL)
    {
        printf("Error creating/appending the file");
    }
    while ((ch = fgetc(fptr)) != EOF)
    {
        fputc(ch, fptr2);
    }
    fclose(fptr);
}
void automatic_saving()
{
    fptr = fopen("hidden.txt", "w");
}
void view_file()
{
    char ch;
    FILE *fptr2;
    char file_name[100];
    printf("Enter file name: ");
    gets(file_name);
    gets(file_name);
    strcat(file_name, ".txt");
    fptr2 = fopen(file_name, "r");

    if (fptr2 == NULL)
    {
        printf("Error creating/appending the file");
    }
    while ((ch = fgetc(fptr2)) != EOF)
    {
        printf("%c", ch);
    }
}
void edit_file()
{
    char ch;
    fclose(fptr);
    FILE *fptr2;
    char file_name[100];
    printf("Enter file name: ");
    gets(file_name);
    gets(file_name);
    strcat(file_name, ".txt");
    fptr2 = fopen(file_name, "r");

    if (fptr2 == NULL)
    {
        printf("Error creating/appending the file");
    }
    while ((ch = fgetc(fptr2)) != EOF)
    {
        printf("%c", ch);
    }
    fclose(fptr2);
    fptr = fopen(file_name, "a");
    option_menu();
}
